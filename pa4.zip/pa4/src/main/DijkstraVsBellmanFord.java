package main;

import benching.Benchmark;
import core.Problem1.DirectedGraph;
import core.Problem1.Graph;
import core.Problem4.BellmanFord;
import core.Problem4.Dijkstra;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;

import static range.Range.range;

public class DijkstraVsBellmanFord {

  public static void main(String[] args) {

    var bm = new Benchmark("dijkstra_vs_bellmanford");
    var seed = System.nanoTime();
    var rand= new Random(seed);

    var upper = 1_000;
    var step  = 100;
    var sizes = range(step, upper, step).toList();
    var reps  = 10;

    final Function<Integer, DirectedGraph> setup = size -> {
      DirectedGraph graph = new DirectedGraph(size);
      for (int i : range(size)) {
        for (int j : range(size)) {
          if (i != j) {
            int weight = rand.nextInt(upper) + 1;
            graph.addEdge(i, j, weight);
          }
        }
      }
      return graph;
    };

    final Consumer<DirectedGraph> fnDijkstra = graph -> {
      new Dijkstra(graph, graph.getRoot().get());
    };
    final Consumer<DirectedGraph> fnBellman = graph -> {
      new BellmanFord(graph, graph.getRoot().get());
    };

    bm.bench("Dijkstra", "dijkstra", setup, fnDijkstra, sizes, reps);
    bm.bench("Bellman-Ford", "bellman_ford", setup, fnBellman, sizes, reps);

  }
}
