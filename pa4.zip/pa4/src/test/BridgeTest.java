import core.Edge;
import core.Problem1.Graph;
import core.Problem1.UndirectedGraph;
import core.Problem6.Bridge;
import logging.Logger;
import logging.Mode;
import testing.Test;
import testing.Unit;

public class BridgeTest {

  private static final Logger log = Logger.builder()
      .mode(Mode.Test)
      .emoji(true)
      .build();

  @Unit
  public void testIsBridge() throws Test.FailException {
    final Graph graph = new UndirectedGraph(4);

    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(3, 4);

    //   0
    //  / \
    // 2   1 -> 3 -> 4

    final Bridge bridge = new Bridge(graph, 0);
    Test.throwAssertQuiet("(0-1) Is a bridge", bridge.isBridge(new Edge(0, 1, 1.0)));
    Test.throwAssertQuiet("(0-2) Is a bridge", bridge.isBridge(new Edge(0, 2, 1.0)));
    Test.throwAssertQuiet("(1-3) Is a bridge", bridge.isBridge(new Edge(1, 3, 1.0)));
    Test.throwAssertQuiet("(3-4) Is a bridge", bridge.isBridge(new Edge(3, 4, 1.0)));
  }

  @Unit
  public void testNotBridge() throws Test.FailException {
    final Graph graph = new UndirectedGraph(4);

    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 2);
    graph.addEdge(1, 3);
    graph.addEdge(3, 4);

    //   0
    //  / \
    // 2 - 1 -> 3 -> 4

    final Bridge bridge = new Bridge(graph, 0);
    Test.throwAssertQuiet("(0-1) Is NOT a bridge", !bridge.isBridge(new Edge(0, 1, 1.0)));
    Test.throwAssertQuiet("(0-2) Is NOT a bridge", !bridge.isBridge(new Edge(0, 2, 1.0)));
    Test.throwAssertQuiet("(1-2) Is NOT a bridge", !bridge.isBridge(new Edge(1, 2, 1.0)));
    Test.throwAssertQuiet("(1-3) Is a bridge", bridge.isBridge(new Edge(1, 3, 1.0)));
    Test.throwAssertQuiet("(3-4) Is a bridge", bridge.isBridge(new Edge(3, 4, 1.0)));

  }
}
