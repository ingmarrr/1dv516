package core.Problem6;

import core.Edge;
import core.Problem1.Graph;

public class Bridge {
  private final Graph graph;
  private boolean[] marked;
  private int[] num;
  private int[] lowestNrReacheable;
  private int counter = 0;

  public Bridge(Graph g, int root) {
    graph = g;
    marked = new boolean[graph.countVertices()];
    num = new int[graph.countVertices()];
    lowestNrReacheable = new int[graph.countVertices()];
    bridgeDfs(root, -1);
  }

  private void bridgeDfs(int vertex, int parent) {
    marked[vertex] = true;
    num[vertex] = lowestNrReacheable[vertex] = counter++;

    for (Edge edge : graph.adjacent(vertex)) {
      int to = edge.to();
      if (!marked[to]) {
        bridgeDfs(to, vertex);
        lowestNrReacheable[vertex] = Math.min(lowestNrReacheable[vertex], lowestNrReacheable[to]);
      } else if (to != parent) {
        lowestNrReacheable[vertex] = Math.min(lowestNrReacheable[vertex], num[to]);
      }
    }
  }

  public boolean isBridge(Edge edge) {
    int v = edge.from();
    int w = edge.to();
    return (lowestNrReacheable[w] > num[v]) || (lowestNrReacheable[v] > num[w]);
  }
}
