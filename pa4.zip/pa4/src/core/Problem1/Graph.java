package core.Problem1;

import core.Edge;

import java.util.List;

/**
 * #edges,
 * #vertices,
 * add edge,
 * remove edge,
 * degree
 */
public interface Graph {
  List<Edge> adjacent(int vtx);
  List<Edge> edges();
  List<Integer> vertices();
  int countEdges();
  int countVertices();
  void addEdge(Edge edge);
  default void addEdge(int from, int to, double weight) {
    addEdge(new Edge(from, to, weight));
  }
  default void addEdge(int from, int to) {
    addEdge(from, to, 1.0);
  }
  void removeEdge(Edge edge);
  default void removeEdge(int from, int to) {
    removeEdge(new Edge(from, to, 1.0));
  }
  int degree(int vtx);
}
