package core.Problem1;

import core.Edge;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static range.Range.range;

public class BaseGraph implements Graph {
  private List<List<Edge>> adj;
  private Optional<Integer> root;

  public Optional<Integer> getRoot() {
    return root;
  }

  public BaseGraph(int init) {
    adj = new ArrayList<>();
    root = Optional.empty();
    while (adj.size() < init) adj.add(new ArrayList<>());
  }

  @Override
  public List<Edge> adjacent(int vtx) {
    if (vtx < adj.size()) return adj.get(vtx);
    return new ArrayList<>();
  }

  @Override
  public List<Edge> edges() {
    ArrayList<Edge> out = new ArrayList<>();
    for (var vtx : adj) {
      out.addAll(vtx);
    }
    return out;
  }

  @Override
  public List<Integer> vertices() {
    ArrayList<Integer> out = new ArrayList<>();
    for (var vtx : adj) {
      if (vtx.size() > 0) out.add(vtx.get(0).from());
    }
    return out;
  }

  @Override
  public int countEdges() {
    var out = 0;
    for (var neighbours : adj) {
      out += neighbours.size();
    }
    return out;
  }

  @Override
  public int countVertices() {
    return adj.size();
  }

  @Override
  public void addEdge(Edge edge) {
    ensureVtxExists(Math.max(edge.from(), edge.to()));
    adj.get(edge.from()).add(edge);
    if (root.isEmpty()) {
      root = Optional.of(edge.from());
    }
  }

  @Override
  public void removeEdge(Edge edge) {
    if (edge.from() < adj.size() && edge.to() < adj.size()) {
      adj.get(edge.from()).remove(edge);
    }
  }

  @Override
  public int degree(int vtx) {
    return adj.get(vtx).size();
  }

  private void ensureVtxExists(int vtx) {
    while (adj.size() <= vtx) {
      adj.add(new ArrayList<>());
    }
  }
}
