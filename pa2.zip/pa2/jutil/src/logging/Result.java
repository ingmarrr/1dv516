package logging;

public enum Result {
  Ok,
  Err
}
